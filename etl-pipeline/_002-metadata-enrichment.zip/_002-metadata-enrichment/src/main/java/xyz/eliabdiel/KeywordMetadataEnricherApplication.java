package xyz.eliabdiel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeywordMetadataEnricherApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeywordMetadataEnricherApplication.class, args);
	}

}
